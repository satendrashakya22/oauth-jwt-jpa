package com.myoauth.server.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.myoauth.server.dao.OAuthDAOService;
import com.myoauth.server.model.CustomUser;
import com.myoauth.server.model.UserEntity;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	OAuthDAOService oauthDAOService;

	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {

		UserEntity userEntity = null;

		try {
			userEntity = oauthDAOService.findByEmailId(emailId);

			if (userEntity != null && userEntity.getId() != null && !"".equalsIgnoreCase(userEntity.getId())) {
				CustomUser customUser = new CustomUser(userEntity);
				return customUser;
			} else {
				throw new UsernameNotFoundException("User " + emailId + " was not found in the database");
			}
		} catch (Exception e) {
			throw new UsernameNotFoundException("User " + emailId + " was not found in the database");
		}

	}

}
