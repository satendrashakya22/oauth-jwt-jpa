package com.myoauth.server.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myoauth.server.model.UserEntity;

public interface OAuthDAOService extends JpaRepository<UserEntity, Long> {

	public UserEntity findByEmailId(String emailId);
}
